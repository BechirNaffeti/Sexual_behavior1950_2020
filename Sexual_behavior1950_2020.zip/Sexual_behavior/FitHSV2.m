clear all
close all
clc

%% Fixed paramters
Nc=4;
Nrisk=5;
Nage=20;
eRisk=0.3;
eAge=0.7;
phi=1/5;
P=[0.01 0 0.01]';
a=1:Nage;
Psi_f=8*(1./(a.*sqrt(2*pi*(0.3948)^2))).*(exp((-(log(a)-1.859).^2)./(2*(0.3948)^2)));
Psi_m=5*(1./(a.*sqrt(2*pi*(0.3707)^2))).*(exp((-(log(a)-1.792).^2)./(2*(0.3707)^2)));

%%%%Natural History Parameters
shed_freq=0.183;
length_dur_primary=20;% the recovery of a primary infected is 20 days
cycle_freq=15; %times per year the reactivation happens
taux1 = length_dur_primary; 
    % duration of latency from latent to reactivation taux2
taux2=365*(1-shed_freq)/cycle_freq;
    %duration of reactivation taux3
taux3=365 * shed_freq / cycle_freq;
    %The progression rates from one stage to other per year is:
pi_1= 365* (1/ taux1); %per year
pi_2= 365* (1/taux2);
pi_3= 365* (1/taux3);
% Power-law function :
theta=2.8;
Risk=1:5;
P_law=Risk.^theta;
q=5.9;
Init_prevM=0.02;
Init_prevF=0.2;
% Transmission Probability:
FrequencyOfCoitalActA=[3.90 3.50 3.20 2.90 2.50 2.20 1.90 1.50 1.20 0.87];  
FrequencyOfCoitalAct=zeros(20,1);
FrequencyOfCoitalAct(4:13)=365.*FrequencyOfCoitalActA/7; %%Per year
Tp=1-((1-P').^FrequencyOfCoitalAct); 
%% import optimal set of paramters
load("DemoParamMale.mat");
load("DemoParamFemale.mat");
DemParam=[optimalvaluesMale;optimalvaluesFemale];

%%%%%%%%%Seroprevalence Data
PrevDataAge_f=100*xlsread('NHANES_Female.xlsx','Female 15-49 years Mean');
PrevDataAge_m=100*xlsread('NHANES_Male.xlsx','male 15-49 years Mean');
PrevDataTot_m=xlsread('NHANES15_49Male');
PrevDataTot_f=xlsread('NHANES15_49Female');
PrevTotal=xlsread('NHANESTotalPrevalence.xlsx','HSV-2 overall');
year=[1978 1991 1999.5 2001.5 2003.5 2005.5 2007.5 2009.5 2011.5 2013.5 2015.5];
PrevalenceTotal=[year',PrevTotal(:,3)];

%% Create Initial solution
Population_M=[1487440, 1339054, 1202703, 1077780, 963656, 859687,765222, 679617, 602233, 532437, 469580, 412947, 361611, 314170, 268546, 223114, 179438, 141095, 109723, 84906];
Population_F=[1701110, 1534675, 1381123, 1239871, 1110293, 991729, 883470, 784737, 694640, 612093, 535667, 463376, 392440, 319392, 241544, 161045, 88839, 38716, 13352, 3825];
RiskGroupPopulationFactorsMales=[0.1307,0.6577,0.0811,0.0358,0.0947];
RiskGroupPopulationFactorsFemales=[0.1736,0.6828,0.0848,0.0299,0.0289];
N_0_M=RiskGroupPopulationFactorsMales.*(Population_M)';
N_0_F=RiskGroupPopulationFactorsFemales.*(Population_F)';

S0_M=N_0_M;
S0_M(4:13,:)=(1-Init_prevM).*N_0_M(4:13,:);
I10_M=zeros(Nage,Nrisk);
I10_M(4:13,:)=Init_prevM.*N_0_M(4:13,:);
I20_M=zeros(Nage,Nrisk);
I30_M=zeros(Nage,Nrisk);
S0_F=N_0_F;
S0_F(4:13,:)=(1-Init_prevF).*N_0_F(4:13,:);
I10_F=zeros(Nage,Nrisk);
I10_F(4:13,:)=Init_prevF.*N_0_F(4:13,:);
I20_F=zeros(Nage,Nrisk);
I30_F=zeros(Nage,Nrisk);

x0_M=[];
x0_F=[];
for b=1:Nage
    for i=1:Nrisk
        x0_M=[x0_M, S0_M(b,i),I10_M(b,i),I20_M(b,i),I30_M(b,i)];
        x0_F=[x0_F, S0_F(b,i),I10_F(b,i),I20_F(b,i),I30_F(b,i)];
    end
end
SolInitial=[x0_M,x0_F];



%%   Optimization Part 
lb=0.004*ones(1,15);
lb(15)=0.007;
ub=0.1*ones(1,15);
%x0=(0.02-0.005).*rand(1,15) + 0.005;
x0=[ 0.0093641981007893341365511119533949, 0.0064129320700485768422249854836537, 0.0060791957379646857986821295583013, 0.0069029311332555205044103630029895, 0.010804000163012337371037929756312, 0.012469350733043237794417379404877, 0.014992321609734248627487929184099, 0.014481361335731865805365181643083, 0.012644456688788632131581479711713, 0.0068511313325246700131621047091812, 0.0062592918851844918382010263258053, 0.0069741866024982442778812341543926, 0.0060000114559267464162117811099506, 0.0060330151736852112576148243761054, 0.0063190571089924100350865288078239];
options=optimset('Display','iter','TolFun',1e-8,'MaxIter',1000,'MaxFunEvals',3000,'PlotFcns',@optimplotfval);
optimal=fminsearchbnd(@ObjectiveFunction,x0,lb,ub,options,PrevDataAge_f,PrevDataAge_m,PrevDataTot_m,PrevDataTot_f,Nc,Nrisk,Nage,eRisk,eAge,DemParam,Psi_m,Psi_f,P_law,phi,pi_1,pi_2,pi_3,Tp,q, SolInitial);                                                           
Rho_fit=optimal;
%save("OptimalRho_fit.mat","Rho_fit")











%% Simulation
% xr=[1968 40 0.85 0.01  0.7];
% ObjectiveFunction2(xr,Nc,Nr,Nb,eRisk,eAge,Optimal,PsiM,PsiF,Pwlaw,eta,pi_1,pi_2,pi_3,TransmissionProb,PrevdataAgeM,PrevdataAgeF,PrevTM,PrevTF,PrevalenceTotal,SolInitial)
 

 



