function Error = ObjectiveFunction(x,PrevDataAge_f,PrevDataAge_m,PrevDataTot_m,PrevDataTot_f,Nc,Nrisk,Nage,eRisk,eAge,DemParam,Psi_m,Psi_f,P_law,phi,pi_1,pi_2,pi_3,Tp,q, SolInitial)
 

t0=1850;
tf=2015.5;
dt=0.5;
tspan=t0:0.5:tf+dt;
[t,y]=ode15s(@ModelHSV2, tspan,SolInitial, [],Nc,Nrisk,Nage,eRisk,eAge,DemParam,Psi_m,Psi_f,P_law,phi,pi_1,pi_2,pi_3,Tp,x,q);


SMv=y(:,1:Nc:Nc*Nrisk*Nage);
I1Mv=y(:,2:Nc:Nc*Nrisk*Nage);
I2Mv=y(:,3:Nc:Nc*Nrisk*Nage);
I3Mv=y(:,4:Nc:Nc*Nrisk*Nage);
SFv=y(:,Nc*Nrisk*Nage+1:Nc:2*Nc*Nrisk*Nage);
I1Fv=y(:,Nc*Nrisk*Nage+2:Nc:2*Nc*Nrisk*Nage);
I2Fv=y(:,Nc*Nrisk*Nage+3:Nc:2*Nc*Nrisk*Nage);
I3Fv=y(:,Nc*Nrisk*Nage+4:Nc:2*Nc*Nrisk*Nage);
for b=1:Nage
    S_m(:,:,b)=SMv(:,(b-1)*Nrisk+(1:5));
    S_f(:,:,b)=SFv(:,(b-1)*Nrisk+(1:5));
    I1_m(:,:,b)=I1Mv(:,(b-1)*Nrisk+(1:5));
    I1_f(:,:,b)=I1Fv(:,(b-1)*Nrisk+(1:5));
    I2_m(:,:,b)=I2Mv(:,(b-1)*Nrisk+(1:5));
    I2_f(:,:,b)=I2Fv(:,(b-1)*Nrisk+(1:5));
    I3_m(:,:,b)=I3Mv(:,(b-1)*Nrisk+(1:5));
    I3_f(:,:,b)=I3Fv(:,(b-1)*Nrisk+(1:5));
end




PrevalenceAgeM=(sum(I1_m,2)+sum(I2_m,2)+sum(I3_m,2))./(sum(S_m,2)+sum(I1_m,2)+sum(I2_m,2)+sum(I3_m,2));
PrevalenceAgeM=100*reshape(PrevalenceAgeM,length(t),Nage);
PrevalenceAgeF=(sum(I1_f,2)+sum(I2_f,2)+sum(I3_f,2))./(sum(S_f,2)+sum(I1_f,2)+sum(I2_f,2)+sum(I3_f,2));
PrevalenceAgeF=100*reshape(PrevalenceAgeF,length(t),Nage);
PrevalenceAgeM_15_49=100*sum((sum(I1_m(:,:,4:10),2)+sum(I2_m(:,:,4:10),2)+sum(I3_m(:,:,4:10),2)),3)./sum((sum(S_m(:,:,4:10),2)+sum(I1_m(:,:,4:10),2)+sum(I2_m(:,:,4:10),2)+sum(I3_m(:,:,4:10),2)),3);
PrevalenceAgeF_15_49=100*sum((sum(I1_f(:,:,4:10),2)+sum(I2_f(:,:,4:10),2)+sum(I3_f(:,:,4:10),2)),3)./sum((sum(S_f(:,:,4:10),2)+sum(I1_f(:,:,4:10),2)+sum(I2_f(:,:,4:10),2)+sum(I3_f(:,:,4:10),2)),3);
years=[1978 1991 1999.5 2001.5 2003.5 2005.5 2007.5 2009.5 2011.5 2013.5 2015.5];

differ=zeros(8,1);
differ(3)=5*sum((PrevalenceAgeM((years(2)-t0+0.5)*2,4:19)-PrevDataAge_m(2,5:20)).^2);
differ(4)=5*sum((PrevalenceAgeF((years(2)-t0+0.5)*2,4:19)-PrevDataAge_f(2,5:20)).^2);
for t1=3:length(years)
       differ(5)=differ(5)+sum((PrevalenceAgeM((years(t1)-t0+0.5)*2,4:10)-PrevDataAge_m(t1,5:11)).^2); 
       differ(6)=differ(6)+sum((PrevalenceAgeF((years(t1)-t0+0.5)*2,4:10)-PrevDataAge_f(t1,5:11)).^2);
end    
for t1=2:length(years)
      differ(7)=differ(7)+5*((PrevalenceAgeM_15_49((years(t1)-t0+0.5)*2)-PrevDataTot_m(t1,2)).^2);
      differ(8)=differ(8)+10*((PrevalenceAgeF_15_49((years(t1)-t0+0.5)*2)-PrevDataTot_f(t1,2)).^2);   
end 
Error=sum(differ(1:6))+30*sum(differ(7:8));
end