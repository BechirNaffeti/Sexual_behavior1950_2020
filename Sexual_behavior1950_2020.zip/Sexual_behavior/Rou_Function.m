function y=Rou_Function(t,x)
index=(1*(t<1950))+((floor((t - 1950) /5) + 2).*((t<2020)&(t>=1950)))+ 15*(t>=2020);
y=x(index);
end

