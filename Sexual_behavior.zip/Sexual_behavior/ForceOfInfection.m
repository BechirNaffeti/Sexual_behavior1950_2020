function [L,lambda_m,lambda_f]= ForceOfInfection(t,I1_m,I2_m,I3_m,I1_f,I2_f,I3_f,Nrisk,Nage,Rho_m,Rho_f,N_m,N_f,G_m,G_f,H_m,H_f,q,Tp) 

% lambda_m contact rate for male  
% lambda_f contact rate for female 

lambda_m=zeros(Nage,Nrisk);
lambda_f=zeros(Nage,Nrisk);


for b=1:Nage
    Infected_f{b}=sum((Tp(b,:)').*[I1_f(b,:);I2_f(b,:);I3_f(b,:)])./N_f(b,:);
    Infected_m{b}=sum((Tp(b,:)').*[I1_m(b,:);I2_m(b,:);I3_m(b,:)])./N_m(b,:);
end




for a=4:13
  for i=1:Nrisk
      RM1=reshape(Rho_m(a,i,:,:),Nage,Nrisk);
      RF1=reshape(Rho_f(a,i,:,:),Nage,Nrisk);
          for b=4:13    
              lambda_m(a,i)=lambda_m(a,i)+sum(RM1(b,:).*H_m(a,b).*G_m(i,:,b).*Infected_f{b});
              lambda_f(a,i)=lambda_f(a,i)+sum(RF1(b,:).*H_f(a,b).*G_f(i,:,b).*Infected_m{b});
          end 
      
      
  end
end
lambda_f=q*lambda_f;
L=[lambda_m(:);lambda_f(:)];
end