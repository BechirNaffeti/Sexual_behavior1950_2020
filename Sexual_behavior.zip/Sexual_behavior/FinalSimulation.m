clear all
close all 
clc

%% Fixed paramters
Nc=4;
Nrisk=5;
Nage=20;
eRisk=0.3;
eAge=0.7;
q=5.9;
Init_prevM=0.2;
Init_prevF=0.4;
P=[0.01 0 0.01]';
a=1:Nage;
Psi_f=8*(1./(a.*sqrt(2*pi*(0.3948)^2))).*(exp((-(log(a)-1.859).^2)./(2*(0.3948)^2)));
Psi_m=5*(1./(a.*sqrt(2*pi*(0.3707)^2))).*(exp((-(log(a)-1.792).^2)./(2*(0.3707)^2)));

%%%%Natural History Parameters
shed_freq=0.183;
length_dur_primary=20;% the recovery of a primary infected is 20 days
cycle_freq=15; %times per year the reactivation happens
taux1 = length_dur_primary; 
    % duration of latency from latent to reactivation taux2
taux2=365*(1-shed_freq)/cycle_freq;
    %duration of reactivation taux3
taux3=365 * shed_freq / cycle_freq;
    %The progression rates from one stage to other per year is:
pi_1= 365* (1/ taux1); %per year
pi_2= 365* (1/taux2);
pi_3= 365* (1/taux3);
phi=1/5;
theta=2.8;
Risk=1:5;
P_law=Risk.^theta;
FrequencyOfCoitalActA=[3.90 3.50 3.20 2.90 2.50 2.20 1.90 1.50 1.20 0.87];  
FrequencyOfCoitalAct=zeros(20,1);
FrequencyOfCoitalAct(4:13)=365.*FrequencyOfCoitalActA/7; %%Per year
Tp=1-((1-P').^FrequencyOfCoitalAct); 
load("DemoParamMale.mat");
load("DemoParamFemale.mat");
DemParam=[optimalvaluesMale;optimalvaluesFemale];
%%%%%%%%%Seroprevalence Data
PrevDataAge_f=100*xlsread('NHANES_Female.xlsx','Female 15-49 years Mean');
PrevDataAge_m=100*xlsread('NHANES_Male.xlsx','male 15-49 years Mean');
PrevDataTot_m=xlsread('NHANES15_49Male');
PrevDataTot_f=xlsread('NHANES15_49Female');
PrevTotal=xlsread('NHANESTotalPrevalence.xlsx','HSV-2 overall');
datalower_f=100*xlsread('NHANES_Female.xlsx','Female 15-49 years Lower');
datalower_m=100*xlsread('NHANES_Male.xlsx','male 15-49 years Lower');
dataupper_f=100*xlsread('NHANES_Female.xlsx','Female 15-49 years Upper');
dataupper_m=100*xlsread('NHANES_Male.xlsx','male 15-49 years Upper');
year=[1978 1991 1999.5 2001.5 2003.5 2005.5 2007.5 2009.5 2011.5 2013.5 2015.5];
PrevalenceTotal=[year',PrevTotal(:,3)];












load("OptimalRho_fit.mat");
x_fit=Rho_fit;

%% Create Initial solution
Population_M=[1487440, 1339054, 1202703, 1077780, 963656, 859687,765222, 679617, 602233, 532437, 469580, 412947, 361611, 314170, 268546, 223114, 179438, 141095, 109723, 84906];
Population_F=[1701110, 1534675, 1381123, 1239871, 1110293, 991729, 883470, 784737, 694640, 612093, 535667, 463376, 392440, 319392, 241544, 161045, 88839, 38716, 13352, 3825];
RiskGroupPopulationFactorsMales=[0.1307,0.6577,0.0811,0.0358,0.0947];
RiskGroupPopulationFactorsFemales=[0.1736,0.6828,0.0848,0.0299,0.0289];
N_0_M=RiskGroupPopulationFactorsMales.*(Population_M)';
N_0_F=RiskGroupPopulationFactorsFemales.*(Population_F)';
S0_M=N_0_M;
S0_M(4:13,:)=(1-Init_prevM).*N_0_M(4:13,:);
I10_M=zeros(Nage,Nrisk);
I10_M(4:13,:)=Init_prevM.*N_0_M(4:13,:);
I20_M=zeros(Nage,Nrisk);
I30_M=zeros(Nage,Nrisk);
S0_F=N_0_F;
S0_F(4:13,:)=(1-Init_prevF).*N_0_F(4:13,:);
I10_F=zeros(Nage,Nrisk);
I10_F(4:13,:)=Init_prevF.*N_0_F(4:13,:);
I20_F=zeros(Nage,Nrisk);
I30_F=zeros(Nage,Nrisk);

x0_M=[];
x0_F=[];
for b=1:Nage
    for i=1:Nrisk
        x0_M=[x0_M, S0_M(b,i),I10_M(b,i),I20_M(b,i),I30_M(b,i)];
        x0_F=[x0_F, S0_F(b,i),I10_F(b,i),I20_F(b,i),I30_F(b,i)];
    end
end
SolInitial=[x0_M,x0_F];
t0=1850;
tf=2100;
dt=0.5;
tspan=t0:0.5:tf+dt;
[t,y]=ode15s(@ModelHSV2, tspan,SolInitial,[],Nc,Nrisk,Nage,eRisk,eAge,DemParam,Psi_m,Psi_f,P_law,phi,pi_1,pi_2,pi_3,Tp,x_fit,q);


SMv=y(:,1:Nc:Nc*Nrisk*Nage);
I1Mv=y(:,2:Nc:Nc*Nrisk*Nage);
I2Mv=y(:,3:Nc:Nc*Nrisk*Nage);
I3Mv=y(:,4:Nc:Nc*Nrisk*Nage);
SFv=y(:,Nc*Nrisk*Nage+1:Nc:2*Nc*Nrisk*Nage);
I1Fv=y(:,Nc*Nrisk*Nage+2:Nc:2*Nc*Nrisk*Nage);
I2Fv=y(:,Nc*Nrisk*Nage+3:Nc:2*Nc*Nrisk*Nage);
I3Fv=y(:,Nc*Nrisk*Nage+4:Nc:2*Nc*Nrisk*Nage);


for b=1:Nage
    S_m(:,:,b)=SMv(:,(b-1)*Nrisk+(1:5));
    S_f(:,:,b)=SFv(:,(b-1)*Nrisk+(1:5));
    I1_m(:,:,b)=I1Mv(:,(b-1)*Nrisk+(1:5));
    I1_f(:,:,b)=I1Fv(:,(b-1)*Nrisk+(1:5));
    I2_m(:,:,b)=I2Mv(:,(b-1)*Nrisk+(1:5));
    I2_f(:,:,b)=I2Fv(:,(b-1)*Nrisk+(1:5));
    I3_m(:,:,b)=I3Mv(:,(b-1)*Nrisk+(1:5));
    I3_f(:,:,b)=I3Fv(:,(b-1)*Nrisk+(1:5));
end
%% Prevalence Men
PrevalenceAgeM=(sum(I1_m,2)+sum(I2_m,2)+sum(I3_m,2))./(sum(S_m,2)+sum(I1_m,2)+sum(I2_m,2)+sum(I3_m,2));
PrevalenceAgeMP=reshape(PrevalenceAgeM,length(t),Nage);
PrevalenceAgeF=(sum(I1_f,2)+sum(I2_f,2)+sum(I3_f,2))./(sum(S_f,2)+sum(I1_f,2)+sum(I2_f,2)+sum(I3_f,2));
PrevalenceAgeFP=reshape(PrevalenceAgeF,length(t),Nage);

PrevalenceAgeM_15_49P=sum((sum(I1_m(:,:,4:10),2)+sum(I2_m(:,:,4:10),2)+sum(I3_m(:,:,4:10),2)),3)./sum((sum(S_m(:,:,4:10),2)+sum(I1_m(:,:,4:10),2)+sum(I2_m(:,:,4:10),2)+sum(I3_m(:,:,4:10),2)),3);
PrevalenceAgeF_15_49P=sum((sum(I1_f(:,:,4:10),2)+sum(I2_f(:,:,4:10),2)+sum(I3_f(:,:,4:10),2)),3)./sum((sum(S_f(:,:,4:10),2)+sum(I1_f(:,:,4:10),2)+sum(I2_f(:,:,4:10),2)+sum(I3_f(:,:,4:10),2)),3);
S=S_m+S_f;I1=I1_m+I1_f;I2=I2_m+I2_f;I3=I3_m+I3_f;
PrevalenceTP=sum((sum(I1(:,:,4:10),2)+sum(I2(:,:,4:10),2)+sum(I3(:,:,4:10),2)),3)./sum((sum(S(:,:,4:10),2)+sum(I1(:,:,4:10),2)+sum(I2(:,:,4:10),2)+sum(I3(:,:,4:10),2)),3);


%% PLOT 
% By  age men
years=[1991 1999.5 2001.5 2003.5 2005.5 2007.5 2009.5 2011.5 2013.5 2015.5];
years1=["1988-1994", "1999-2000", "2001-2002" , "2003-2004"  , "2005-2006" , "2007-2008" , "2009-2010" , "2011-2012", "2013-2014", "2015-2016"];
figure,
subplot(4,3,1)
hold on
plot(1:20,PrevalenceAgeMP((years(1)-t0+0.5)*2,1:20)*100,'b-','LineWidth',1.5)
DATAPredictM=PrevalenceAgeMP((years(1)-t0+0.5)*2,4:18);
DATATrueM=PrevDataAge_m(2,5:19);
RM_m(1)=sum((DATAPredictM-DATATrueM).^2);
n_m(1)=length(DATATrueM);
UPPERDATAM=dataupper_m(2,5:19)-PrevDataAge_m(2,5:19);
LOWERDATAM=PrevDataAge_m(2,5:19)-datalower_m(2,5:19);
hold on
errorbar(4:18,PrevDataAge_m(2,5:19),LOWERDATAM,UPPERDATAM,'r*')
legend('Model fit','NHANES data')
ylabel({'HSV-2 seroprevalence';' among men (%)'})
ylim([0,40])
xlim([0,21])
title(years1(1))
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'}); 

for j=2:10
subplot(4,3,j)
hold on
plot(1:20,PrevalenceAgeMP((years(j)-t0+0.5)*2,1:20)*100,'b-','LineWidth',1.5)
UPPERDATAM=dataupper_m(j+1,5:11)-PrevDataAge_m(j+1,5:11);
LOWERDATAM=PrevDataAge_m(j+1,5:11)-datalower_m(j+1,5:11);
DATAPredictM=PrevalenceAgeMP((years(j)-t0+0.5)*2,4:10);
DATATrueM=PrevDataAge_m(j+1,5:11);
RM_m(j)=sum((DATAPredictM-DATATrueM).^2);
n_m(j)=length(DATATrueM);
hold on
errorbar(4:10,PrevDataAge_m(j+1,5:11),LOWERDATAM,UPPERDATAM,'r*')
legend('Model fit','NHANES data')
ylabel({'HSV-2 seroprevalence';' among men (%)'})
ylim([0,40])
xlim([0,21])
title(years1(j))
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'}); 

end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% By  age women

figure,
subplot(4,3,1)
hold on
plot(1:20,PrevalenceAgeFP((years(1)-t0+0.5)*2,1:20)*100,'b-','LineWidth',1.5)
UPPERDATAM=dataupper_f(2,5:19)-PrevDataAge_f(2,5:19);
LOWERDATAM=PrevDataAge_f(2,5:19)-datalower_f(2,5:19);

DATAPredictF=PrevalenceAgeFP((years(1)-t0+0.5)*2,4:18);
DATATrueF=PrevDataAge_f(2,5:19);
RM_f(1)=sum((DATAPredictF-DATATrueF).^2);
n_f(1)=length(DATATrueF);
hold on
errorbar(4:18,PrevDataAge_f(2,5:19),LOWERDATAM,UPPERDATAM,'r*')
legend('Model fit','NHANES data')
ylabel({'HSV-2 seroprevalence';' among total women (%)'})
ylim([0,60])
xlim([0,21])
title(years1(1))
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'}); 

for j=2:10
subplot(4,3,j)
hold on
plot(1:20,PrevalenceAgeFP((years(j)-t0+0.5)*2,1:20)*100,'b-','LineWidth',1.5)

DATAPredictF=PrevalenceAgeFP((years(j)-t0+0.5)*2,4:10);
DATATrueF=PrevDataAge_f(j+1,5:11);
RM_f(j)=sum((DATAPredictF-DATATrueF).^2);
n_f(j)=length(DATATrueF);

UPPERDATAM=dataupper_f(j+1,5:11)-PrevDataAge_f(j+1,5:11);
LOWERDATAM=PrevDataAge_f(j+1,5:11)-datalower_f(j+1,5:11);
hold on
errorbar(4:10,PrevDataAge_f(j+1,5:11),LOWERDATAM,UPPERDATAM,'r*')
legend('Model fit','NHANES data')
ylabel({'HSV-2 seroprevalence';' among women (%)'})
ylim([0,60])
xlim([0,21])
title(years1(j))
xticks([5 10 15 20])
xticklabels({'20-24','45-49','70-74','95-99'}); 

end



figure,
subplot(2,1,1)
hold on
plot(t,PrevalenceTP*100,'k-','LineWidth',1.5)
UpperDat=PrevTotal(2:end,5)-PrevTotal(2:end,3);
LowerDat=PrevTotal(2:end,3)-PrevTotal(2:end,4);
errorbar(years,PrevTotal(2:end,3),UpperDat,LowerDat,'k*')
datapredictTotal=100*PrevalenceTP((years - t0 + 0.5)*2);
dataTrueTotal=PrevTotal(2:end,3);
n_T=length(dataTrueTotal);
RM_Total=sum((datapredictTotal-dataTrueTotal).^2);

ylabel({'HSV-2 seroprevalence among all';'individuals aged 15-49 years (%)'})
legend('Model fit','NHANES data')
title('(A)')
xlabel('Year')
xlim([1950,2020])
ylim([0,30])
xticks([1950:10:2050])
yticks(0:10:50)

subplot(2,1,2)
hold on
plot(t((1850-t0+0.5)*2:end),PrevalenceAgeF_15_49P((1850-t0+0.5)*2:end)*100,'r',t((1850-t0+0.5)*2:end),PrevalenceAgeM_15_49P((1850-t0+0.5)*2:end)*100,'b','LineWidth',1.5)
UpperDatM=PrevDataTot_m(2:end,4)-PrevDataTot_m(2:end,2);
LowerDatM=PrevDataTot_m(2:end,2)-PrevDataTot_m(2:end,3);
UpperDatF=PrevDataTot_f(2:end,4)-PrevDataTot_f(2:end,2);
LowerDatF=PrevDataTot_f(2:end,2)-PrevDataTot_f(2:end,3);
errorbar(years,PrevDataTot_f(2:end,2),UpperDatF,LowerDatF,'r*')
errorbar(years,PrevDataTot_m(2:end,2),UpperDatM,LowerDatM,'b*')
plot(years,PrevDataTot_f(2:end,2),'r*',years,PrevDataTot_m(2:end,2),'b*')

datapredictTotalWomen=100*PrevalenceAgeF_15_49P((years - t0 + 0.5)*2);
dataTrueTotalWomen=PrevDataTot_f(2:end,2);
RM_Totalf=sum((datapredictTotalWomen-dataTrueTotalWomen).^2);

n_Tf=length(dataTrueTotalWomen);

datapredictTotalMen=100*PrevalenceAgeM_15_49P((years - t0 + 0.5)*2);
dataTrueTotalMen=PrevDataTot_m(2:end,2);
RM_TotalM=sum((datapredictTotalMen-dataTrueTotalMen).^2);
n_Tm=length(dataTrueTotalMen);

ylabel({'Sex-specific HSV-2 seroprevalence among ';'individuals aged 15-49 years (%)'})
xlabel('Year')
xlim([1950,2050])
ylim([0,50])
legend({'Model fit for women', 'Model fit for men','NHANES data for women','NHANES data for men'},'NumColumns',2)
title('B')
xticks([1950:10:2050])
yticks(0:10:50)
RMSE=sqrt(sum(RM_f+RM_m+RM_Total+RM_Totalf+RM_TotalM)/sum(n_m+n_f+n_T+n_Tf+n_Tm))

figure,
plot(1950:2020,Rou_Function(1950:2020,x_fit))
ylabel({'Sexual risk behavior (arbitrary units).'})
h = gca;
h.YAxis.Visible = 'off';
set(get(gca,'YLabel'),'visible','on')
ylim([0,0.025])
xlabel('Year')
