function y = Mortality_Function(t,age,c0,c1,c2,c3,c4)
y=((c0.*1e1).*exp(-((t-(c1.*1e3))./(c2.*1e4)).^2)).*(1./(1+exp(-c3.*(age-(c4.*1e3)))));
end

