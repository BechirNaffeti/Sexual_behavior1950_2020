function y = Birth_Function(t,b0,b1,b2)
y=b0.*exp(-((t-(b1.*1e3))./(b2.*1e4)).^2);
end


