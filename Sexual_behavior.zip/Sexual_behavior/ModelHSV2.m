function  [dydt,lambda_m,lambda_f] = ModelHSV2(t,y,Nc,Nrisk,Nage,eRisk,eAge,DemParam,Psi_m,Psi_f,P_law,phi,pi_1,pi_2,pi_3,Tp,x,q)

% %****reshaping the vector y***  
S_m=(reshape(y(1:Nc:Nc*Nage*Nrisk),Nrisk,Nage))';
S_f=(reshape(y(Nc*Nage*Nrisk+1:Nc:2*Nc*Nage*Nrisk),Nrisk,Nage))'; 
I1_m=(reshape(y(2:Nc:Nc*Nage*Nrisk),Nrisk,Nage))';
I1_f=(reshape(y(Nc*Nage*Nrisk+2:Nc:2*Nc*Nage*Nrisk),Nrisk,Nage))'; 
I2_m=(reshape(y(3:Nc:Nc*Nage*Nrisk),Nrisk,Nage))';
I2_f=(reshape(y(Nc*Nage*Nrisk+3:Nc:2*Nc*Nage*Nrisk),Nrisk,Nage))';
I3_m=(reshape(y(4:Nc:Nc*Nage*Nrisk),Nrisk,Nage))';
I3_f=(reshape(y(Nc*Nage*Nrisk+4:Nc:2*Nc*Nage*Nrisk),Nrisk,Nage))';

%%  population at each age and risk group
N_m=S_m+I1_m+I2_m+I3_m;
N_f=S_f+I1_f+I2_f+I3_f;
N_mTotal=sum(N_m);
N_fTotal=sum(N_f);
% %  Calculation of Rho for male and female
index=(1*(t<1950))+((floor((t - 1950) /5) + 2).*((t<2020)&(t>=1950)))+ 15*(t>=2020);
eta=x(index);
Rho1_m=(Psi_m').*eta.*P_law;
Rho1_f=(Psi_f').*eta.*P_law;
%% Etape 1: Determination of the sexuel mixing matrix G
deltaAge=eye(Nage);
deltaRisk=eye(Nrisk);
ROUX_m=Rho1_m.*(S_m+I1_m+I2_m+I3_m);
ROUX_f=Rho1_f.*(S_f+I1_f+I2_f+I3_f);
G=zeros(Nrisk,Nrisk,Nage);
 for b=4:13  
     G_m(:,:,b)=(eRisk*deltaRisk)+((1-eRisk)*ROUX_f(b,:)./sum(ROUX_f(b,:)));
     G_f(:,:,b)=(eRisk*deltaRisk)+((1-eRisk)*ROUX_m(b,:)./sum(ROUX_m(b,:)));
 end
 %% Etape 2: Determination of the age mixing matrix H
 H_m=zeros(Nage,Nage);
 H_f=zeros(Nage,Nage);
 H_m=(eAge*deltaAge)+((1-eAge).*(sum(ROUX_f,2)')./sum(sum(ROUX_f,2)));
 H_f=(eAge*deltaAge)+((1-eAge).*(sum(ROUX_m,2)')./sum(sum(ROUX_m,2)));

 %% Balancing
B=zeros(Nage,Nrisk,Nage,Nrisk);
Rho_m=zeros(Nage,Nrisk,Nage,Nrisk);
Rho_f=zeros(Nage,Nrisk,Nage,Nrisk);
B_m=zeros(Nage,Nrisk,Nage,Nrisk);
B_f=zeros(Nage,Nrisk,Nage,Nrisk);
  w=0.5;
   for a=4:13
       for i=1:Nrisk
           for b=4:13
               for j=1:Nrisk
                   B_m(a,i,b,j)=Rho1_m(a,i).*H_m(a,b)*G_m(i,j,b)*N_m(a,i);
                   B_f(a,i,b,j)=Rho1_f(b,j).*H_f(b,a)*G_f(j,i,a)*N_f(b,j);
                   B(a,i,b,j)= (B_m(a,i,b,j))./(B_f(a,i,b,j)); 
                   Rho_m(a,i,b,j)=Rho1_m(a,i)*(B(a,i,b,j).^-0.5);
                   Rho_f(b,j,a,i)=Rho1_f(b,j)*(B(a,i,b,j).^0.5);
                   
               end
           end
           
       end
   end
%%
xt=y;
%****population at each risk group
N_0=[N_mTotal;N_fTotal];
[L,lambda_m,lambda_f]= ForceOfInfection(t,I1_m,I2_m,I3_m,I1_f,I2_f,I3_f,Nrisk,Nage,Rho_m,Rho_f,N_m,N_f,G_m,G_f,H_m,H_f,q,Tp);
Birth_rate=Birth_Function(t,DemParam(:,1),DemParam(:,2),DemParam(:,3));
Mortality_rate=Mortality_Function(t,1:Nage,DemParam(:,4),DemParam(:,5),DemParam(:,6),DemParam(:,7),DemParam(:,8));
%%

dx=zeros(2*Nc*Nrisk*Nage,1);
S=(1:2)';
%% b=1 
b=1;
i=1:Nrisk;
dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1)= (Birth_rate.*N_0)-(Mortality_rate(:,1).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1))-(L((S-1)*Nrisk*Nage+(i-1)*Nage+b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1))-(phi*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1));
dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2)= (L((S-1)*Nrisk*Nage+(i-1)*Nage+b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1))-(Mortality_rate(:,1).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2))-(pi_1.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2))-(phi.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2));
dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3)= (pi_1.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2))-(Mortality_rate(:,1).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3))-(pi_2*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3))+(pi_3*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4))-(phi*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3));              
dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4)= (pi_2*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3))-(Mortality_rate(:,1).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4))-(pi_3*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4))-(phi*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4));  
                        
%%  b>1   
 for b=2:Nage-1   
 dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1)= (phi.*xt((S-1)*Nc*Nrisk*Nage+((b-2)*Nc*Nrisk)+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1))-(L((S-1)*Nrisk*Nage+(i-1)*Nage+b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1))-(phi.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1));
 dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nrisk*Nc+(i-1)*Nc+2)=(phi.*xt((S-1)*Nc*Nrisk*Nage+((b-2)*Nc*Nrisk)+(i-1)*Nc+2))+(L((S-1)*Nrisk*Nage+(i-1)*Nage+b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2))-(pi_1.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2))-(phi.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2));
 dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nrisk*Nc+(i-1)*Nc+3)=(phi.*xt((S-1)*Nc*Nrisk*Nage+((b-2)*Nc*Nrisk)+(i-1)*Nc+3))+(pi_1*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2))+(pi_3*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4))-(Mortality_rate(:,b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3))-(pi_2.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3))-(phi.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3));
 dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nrisk*Nc+(i-1)*Nc+4)=(phi.*xt((S-1)*Nc*Nrisk*Nage+((b-2)*Nc*Nrisk)+(i-1)*Nc+4))+(pi_2*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4))-(pi_3.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4))-(phi.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4));
 end
 
 b=Nage;
 dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1)= (phi.*xt((S-1)*Nc*Nrisk*Nage+((b-2)*Nc*Nrisk)+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1))-(L((S-1)*Nrisk*Nage+(i-1)*Nage+b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1));
 dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nrisk*Nc+(i-1)*Nc+2)=(phi.*xt((S-1)*Nc*Nrisk*Nage+((b-2)*Nc*Nrisk)+(i-1)*Nc+2))+(L((S-1)*Nrisk*Nage+(i-1)*Nage+b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+1))-(Mortality_rate(:,b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2))-(pi_1.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2));
 dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nrisk*Nc+(i-1)*Nc+3)=(phi.*xt((S-1)*Nc*Nrisk*Nage+((b-2)*Nc*Nrisk)+(i-1)*Nc+3))+(pi_1*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+2))+(pi_3*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4))-(Mortality_rate(:,b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3))-(pi_2.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3));
 dx((S-1)*Nc*Nrisk*Nage+(b-1)*Nrisk*Nc+(i-1)*Nc+4)=(phi.*xt((S-1)*Nc*Nrisk*Nage+((b-2)*Nc*Nrisk)+(i-1)*Nc+4))+(pi_2*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+3))-(Mortality_rate(:,b).*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4))-(pi_3.*xt((S-1)*Nc*Nrisk*Nage+(b-1)*Nc*Nrisk+(i-1)*Nc+4));
dydt=dx;
end
